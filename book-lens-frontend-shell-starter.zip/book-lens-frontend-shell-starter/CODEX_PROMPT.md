# Codex Cloud 작업 지시문

작업 브랜치: `feature/kjs-frontend`

## 목표
현재 Next.js 프론트엔드에 mock 기반 화면 shell을 추가한다. 실제 API 연결이나 action 구현은 하지 않는다. 빌드와 린트가 깨지지 않아야 한다.

## 작업 범위
`frontend/` 하위 파일만 수정한다.

수정 금지:
- `backend/`
- `infra/`
- `docker-compose.yml`
- DB/ERD/migration
- RAG/LangGraph/LLM 구현

## 구현할 화면

### 1. `/books`
도서 검색 화면을 구성한다.

포함 요소:
- 검색 input
- 필터 chip
- mock 도서 카드 목록
- 각 도서 카드에는 제목, 설명, 캐릭터 수, 캐릭터 보기 버튼 표시

### 2. `/chat/[characterId]`
캐릭터 채팅 UI shell을 구성한다.

포함 요소:
- 캐릭터 프로필 영역
- mock 메시지 목록
- 사용자 입력창
- 전송 버튼

주의:
- 실제 메시지 전송 로직은 구현하지 않는다.
- API 연결 위치에 TODO 주석만 남긴다.

### 3. `/settings`
사용자 맞춤 설정 화면을 구성한다.

전제:
- 사용자당 단일 설정 구조
- 필드는 `age_group`, `difficulty_level`, `response_length`, `explanation_style`, `interests`, `instruction`만 사용
- `avoid_topics`, `user_type`, `MBTI`, `multi preset`은 넣지 않음

포함 요소:
- 대상 연령대 선택
- 읽기/이해 수준 선택
- 응답 길이 선택
- 설명 방식 선택
- 관심 주제 선택
- 사용자 지시사항 textarea
- 현재 설정 요약
- 미리보기 shell

주의:
- 저장 버튼은 UI만 구현한다.
- 실제 API 호출은 하지 않는다.

## 공통 요구
- 기존 Next.js App Router 구조 유지
- TypeScript 오류 없음
- Tailwind CSS 사용
- 새 dependency 추가 금지
- 라이트/다크 모드에서 크게 깨지지 않도록 CSS 변수 기반 색상 사용
- 부드러운 동화 서비스 느낌의 카드형 UI 유지
- mock 데이터는 `frontend/src/data/mock.ts`에 분리
- 공통 레이아웃/헤더/카드/칩 컴포넌트는 `frontend/src/components` 하위로 분리
- 모든 실제 API 연결부에는 TODO 주석만 남김

## 예상 파일

수정:
- `frontend/src/app/layout.tsx`
- `frontend/src/app/globals.css`
- `frontend/src/app/page.tsx`

추가:
- `frontend/src/app/books/page.tsx`
- `frontend/src/app/chat/[characterId]/page.tsx`
- `frontend/src/app/settings/page.tsx`
- `frontend/src/components/layout/AppHeader.tsx`
- `frontend/src/components/layout/AppShell.tsx`
- `frontend/src/components/ui/Card.tsx`
- `frontend/src/components/ui/Chip.tsx`
- `frontend/src/components/ui/SectionHeader.tsx`
- `frontend/src/components/ui/SegmentedControl.tsx`
- `frontend/src/components/books/BookSearchShell.tsx`
- `frontend/src/components/books/BookCard.tsx`
- `frontend/src/components/chat/CharacterChatShell.tsx`
- `frontend/src/components/chat/ChatBubble.tsx`
- `frontend/src/components/chat/ChatInputBar.tsx`
- `frontend/src/components/settings/UserPreferenceForm.tsx`
- `frontend/src/components/settings/PreferenceSummary.tsx`
- `frontend/src/components/settings/PreferencePreview.tsx`
- `frontend/src/data/mock.ts`

## 검증
```bash
cd frontend
npm install
npm run lint
npm run build
```

## 작업 후 보고
다음을 정리한다.

- 변경 파일 목록
- lint/build 결과
- 실제 API 미연결 TODO 목록
- 추후 연결해야 할 API 후보

## PR 설명 초안 (실제 작성은 너가 하던 대로 Motivation, Description, Testing, 이외 비고 등의 순서대로 작성해줘)
프론트엔드 화면 shell을 추가했습니다.

포함:
- 도서 검색 화면
- 캐릭터 채팅 UI
- 사용자 맞춤 설정 화면
- 공통 레이아웃/카드/칩 컴포넌트
- mock 데이터

현재는 API 연결 없이 mock 데이터 기준으로 렌더링합니다.
저장, 검색, 채팅 전송은 추후 백엔드 API 확정 후 연결 예정입니다.
