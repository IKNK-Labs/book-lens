# Book Lens Codex 작업 패키지 사용법

이 패키지는 `IKNK-Labs/book-lens` 저장소의 `feature/kim-jeseok-frontend` 브랜치에서 PR #10 이후 논의한 프론트엔드 shell 보강 작업을 Codex Cloud에 맡기기 위한 참조 자료입니다.

## 권장 순서

1. 이 ZIP을 작업 브랜치에 임시로 업로드한다.
2. Codex Cloud에서 `01_codex_plan_prompt_ko.md` 내용을 먼저 보낸다.
   - 이 프롬프트는 `/plan` 모드다.
   - 파일을 수정하지 않고, 현재 코드와 참조 화면을 비교해서 구현 계획만 만든다.
3. 계획이 괜찮으면 `02_codex_apply_prompt_ko.md` 내용을 보낸다.
4. Codex가 패치를 만든 뒤 다음을 확인한다.
   - `frontend` 외 영역을 수정하지 않았는지
   - 참조 ZIP, 압축 해제 reference 폴더, 스크린샷 산출물이 git 변경사항에 남지 않았는지
   - `npm run lint`, `npm run build`, Playwright 시각 검증을 실제로 했는지
5. 패치가 끝나면 이 ZIP과 압축 해제 폴더는 브랜치에서 삭제한다.

## 포함 파일

- `01_codex_plan_prompt_ko.md`: Codex `/plan`용 프롬프트
- `02_codex_apply_prompt_ko.md`: 승인된 계획을 바탕으로 실제 패치 지시용 프롬프트
- `legacy_single_prompt_ko.md`: 이전 단일 프롬프트 백업
- `reference/html`: 정적 HTML 참조 화면
- `reference/screens`: Playwright 스크린샷과 리포트
- `reference/notes`: 화면 맵과 구현 결정 사항
