# Book Lens guest flow preview

PR #10 이후 논의 내용을 기준으로 홈/검색 공개 화면과 로그인 이후 화면을 분리한 정리본입니다.

- 비로그인 공개: `/`, `/books`, `/books/[bookId]`
- 로그인 필요: `/story/[bookId]`, `/chat`, `/settings`
- OAuth 성공 기본 이동: `/settings`

스크린샷은 Playwright Chromium으로 생성했습니다.
