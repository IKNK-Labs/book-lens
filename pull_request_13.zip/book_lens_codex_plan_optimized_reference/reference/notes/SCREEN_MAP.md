# 화면 기준표

이 ZIP은 PR #10 이후 논의한 Book Lens 프론트엔드 shell 보강 작업의 참조 자료입니다. 정적 HTML은 디자인/레이아웃 참고용이며, 실제 구현은 기존 Next.js/Tailwind 컴포넌트 구조에 맞게 반영해야 합니다.

## 화면 파일과 라우트 매핑

| 참조 화면 | 실제 라우트/상태 | 목적 |
|---|---|---|
| `01_flow_overview.html` | 문서용 | 비로그인/로그인 동선 전체 요약 |
| `02_guest_home.html` | `/` 비로그인 | 홈 공개 포털. 동화 검색/추천/인기 캐릭터는 볼 수 있고, 개인 기능은 로그인 유도 |
| `03_guest_books.html` | `/books` 비로그인 | 동화 검색/목록 공개 화면 |
| `04_guest_book_detail.html` | `/books/[bookId]` 비로그인 | 동화 상세 공개 화면. 구연/대화 CTA는 로그인 유도 문구 |
| `05_login_oauth.html` | `/login` | OAuth 로그인/가입 시작 화면. 이메일/비밀번호 폼 없음 |
| `06_mypage_after_oauth.html` | `/settings` 로그인 | 마이페이지 + 대화 설정. OAuth 성공 후 기본 이동 대상 |
| `07_logged_in_home.html` | `/` 로그인 | 로그인 상태 홈. 최근/저장 대화 요약 노출 |
| `08_logged_in_books.html` | `/books` 로그인 | 로그인 상태 검색/목록. 저장/이어가기 맥락 노출 |
| `09_header_user_menu_open.html` | 헤더 메뉴 열린 상태 | `제석님 ▾` 드롭다운: 마이페이지 / 로그아웃 |

## 모바일 기준

스크린샷에는 추가로 아래 모바일 상태가 포함됩니다.

- `10_guest_home_mobile.png`: `/` 비로그인 모바일
- `11_guest_books_mobile.png`: `/books` 비로그인 모바일
- `12_guest_book_detail_mobile.png`: `/books/[bookId]` 비로그인 모바일

모바일 전용 라우트나 별도 파일을 만들지 말고 같은 컴포넌트의 반응형으로 처리합니다.
