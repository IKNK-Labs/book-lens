/plan

# Book Lens 프론트엔드 shell 보강: 구현 전 계획 수립

## 작업 목적

`IKNK-Labs/book-lens` 저장소의 현재 작업 브랜치에서 PR #10 이후 논의된 Book Lens 프론트엔드 화면 흐름을 반영하기 전에, 먼저 현재 코드 구조와 첨부 참조 자료를 확인하고 **구현 계획만** 작성한다.

이번 단계에서는 절대로 파일을 수정하지 않는다. 목표는 오류와 혼선을 줄이기 위해 실제 패치 전에 변경 범위, 파일 구조, 테스트 방법, 위험 요소를 명확히 하는 것이다.

## 현재 전제

- 작업 브랜치: `feature/kim-jeseok-frontend`
- 대상 영역: `frontend`만
- 실제 인증/API 구현이 아니라 프론트엔드 shell 보강
- OAuth, 로그아웃, 회원탈퇴, DB 저장은 mock/TODO만
- 참조 ZIP은 작업 브랜치에 임시 업로드되어 있을 수 있다.
- 참조 ZIP과 압축 해제 폴더는 최종 패치에 남기면 안 된다.

## 참조 자료 확인

먼저 작업 트리에서 다음과 비슷한 이름의 참조 ZIP 또는 폴더를 찾는다.

- `book_lens_codex_plan_optimized_reference.zip`
- `book_lens_codex_branch_patch_reference.zip`
- `book_lens_codex_plan_optimized_reference/`
- `book_lens_codex_branch_patch_reference/`

압축이 필요하면 임시 경로에만 푼다. 예:

```bash
mkdir -p /tmp/book-lens-reference
unzip -q book_lens_codex_plan_optimized_reference.zip -d /tmp/book-lens-reference
```

참조할 파일:

- `reference/screens/contact_sheet.jpg`
- `reference/screens/report.json`
- `reference/notes/SCREEN_MAP.md`
- `reference/notes/IMPLEMENTATION_DECISIONS.md`
- `reference/html/*.html`

정적 HTML은 참고용이다. 그대로 복붙하지 말고 기존 Next.js/Tailwind 컴포넌트 구조에 맞춰 구현 계획을 세운다.

## 구현해야 할 사용자 동선

### 비로그인 상태

비로그인 사용자는 다음 화면을 볼 수 있어야 한다.

- `/` 홈
- `/books` 동화 검색/목록
- `/books/[bookId]` 동화 상세
- `/login` OAuth 시작 화면

비로그인 헤더:

```text
Book Lens        동화        로그인
```

비로그인에서 숨기거나 로그인으로 유도할 것:

- `내 대화`
- 마이페이지
- 동화 구연 진행
- 캐릭터 채팅 진행
- 저장/이어가기 기능

### 로그인 상태

로그인 사용자는 다음 흐름이 보여야 한다.

- `/` 홈: 추천 동화 + 최근/저장 대화 요약
- `/books`: 검색/목록 + 로그인 상태 기준 CTA
- `/books/[bookId]`: 동화 구연 시작, 캐릭터와 대화
- `/story/[bookId]`: 동화 구연 shell
- `/chat`: 내 대화 2단 구조
- `/settings`: 마이페이지 + 대화 설정

로그인 헤더:

```text
Book Lens        동화        내 대화        제석님 ▾
```

사용자명 드롭다운:

```text
마이페이지
로그아웃
```

`회원탈퇴`는 드롭다운에 넣지 않는다. `/settings` 하단의 위험 영역에만 둔다.

## 구현 범위 계획에 반드시 포함할 내용

아래 항목별로 어떤 파일을 만들거나 수정할지 계획한다.

### 1. mock auth/session 구조

- 실제 auth API 없이 로그인/비로그인 상태를 화면에서 검증할 방법을 제안한다.
- 예: `?auth=guest`, `?auth=member` query 또는 route별 mock viewer.
- mock viewer/account 데이터 위치를 정한다.

### 2. AppShell / Header / Footer

- `Book Lens` 옆/아래 회색 보조 문구 제거.
- `AppFooter` 추가 여부와 배치 계획.
- 헤더 로그인/비로그인 표시 계획.
- 사용자명 드롭다운 구현 방식.

### 3. 홈 `/`

- 비로그인 홈과 로그인 홈의 차이를 계획한다.
- 비로그인에서는 홈, 검색, 추천 동화, 인기 캐릭터, 로그인 유도만 표시.
- 로그인에서는 최근/저장 대화 요약을 표시.

### 4. 동화 검색 `/books`

- 비로그인에서도 접근 가능.
- 카드 CTA는 기본적으로 `동화 보기`.
- 바로 캐릭터 채팅으로 보내지 않는다.

### 5. 동화 상세 `/books/[bookId]`

- 새 동적 라우트 필요 여부.
- 줄거리, 장르, 캐릭터 수, 추천 이유, 등장 캐릭터 목록.
- 비로그인 CTA: `로그인하고 구연 시작`, `로그인하고 대화`.
- 로그인 CTA: `동화 구연 시작`, `캐릭터와 대화`.

### 6. 동화 구연 `/story/[bookId]`

- 새 동적 라우트 필요 여부.
- 장면 카드, 나레이션, 대사, 이전/다음 장면, 캐릭터 대화 보조 CTA.
- 실제 생성/음성/API 없음.

### 7. 내 대화 `/chat`

- 데스크톱 2단 구조.
- 왼쪽 `내 대화` 목록 + 검색 input + 검색 버튼.
- 오른쪽 현재 대화.
- 대화 카드 하단 오른쪽에 `이어하기` 버튼 고정.
- 모바일은 상단 접힘 패널.
- 접힘 아이콘은 좌우 drawer 아이콘이 아니라 상하 패널 느낌.

### 8. OAuth `/login`

- `Book Lens 시작하기`.
- `Google로 계속하기`.
- 이메일/비밀번호 폼 없음.
- 데스크톱에서 설명 문구가 어색하게 두 줄로 깨지지 않게 계획.
- 성공 후 기본 이동은 `/settings`로 가정.

### 9. 마이페이지 `/settings`

- 페이지 제목: `마이페이지`.
- 섹션: `계정`, `대화 설정`, `현재 설정 요약`, `위험 영역`.
- 계정: 이름, 이메일, 로그인 방식, 로그아웃.
- 대화 설정: 캐릭터가 부를 이름, 대상 연령대, 읽기/이해 수준, 응답 길이, 설명 방식, 관심 주제, 사용자 지시사항.
- 위험 영역: 회원탈퇴.

### 10. mock data

- stories/books
- characters
- conversation sessions
- viewer/account

대화 세션 식별자는 UI 제목이 아니라 `id` 기준으로 계획한다. UI에는 id를 노출하지 않는다.

## 반드시 지켜야 할 제약

- `frontend` 외 영역 수정 금지.
- backend, infra, 배포 설정 수정 금지.
- 실제 Supabase Auth/OAuth/DB 연동 구현 금지.
- 새 dependency 추가 금지.
- `package.json`, lockfile 수정은 원칙적으로 금지.
- 모바일 전용 라우트나 별도 모바일 파일 생성 금지.
- 라이트/다크 모드 대응을 깨지 않기.
- body/background를 특정 모드로 하드코딩하지 않기.
- UI에 개발자용 설명 문구를 직접 노출하지 않기.
- 참조 ZIP, 압축 해제 폴더, 임시 스크린샷은 최종 변경사항에 남기지 않기.

## 테스트 계획에 반드시 포함할 내용

계획의 마지막에 아래 테스트 방법을 구체적으로 제시한다.

### 정적 검증

```bash
cd frontend
npm run lint
npm run build
```

### Playwright 시각 검증

DOM/CLI 검증만으로 끝내지 않는다. 실제 브라우저로 최소 아래 화면을 확인한다.

Desktop 1440px:

- `/` 비로그인
- `/books` 비로그인
- `/books/[bookId]` 비로그인
- `/login`
- `/settings` 로그인
- `/` 로그인
- `/books` 로그인
- `/chat` 로그인
- 사용자명 드롭다운 열린 상태

Mobile 390px:

- `/` 비로그인
- `/books` 비로그인
- `/books/[bookId]` 비로그인
- `/chat` 로그인, `내 대화` 패널 닫힘/펼침

확인 기준:

- 가로 overflow 없음.
- 버튼/카드가 viewport 밖으로 튀지 않음.
- 헤더 nav가 모바일에서 깨지지 않음.
- OAuth 설명 문구가 데스크톱에서 부자연스럽게 줄바꿈되지 않음.
- 모바일 채팅 제목과 `이어하기` 버튼이 깨지지 않음.
- 라이트/다크 모드에서 배경과 카드 대비 유지.

## 계획 출력 형식

아래 형식으로만 답한다.

1. 현재 코드 구조 확인 결과
2. 참조 자료 확인 결과
3. 구현 계획
   - 파일별 변경 예정 목록
   - 라우트별 변경 예정 내용
   - 컴포넌트 분리 계획
4. mock auth/session 처리 계획
5. 테스트 계획
6. 위험 요소와 방지책
7. 구현 전에 사용자에게 확인할 질문

다시 강조한다. 이번 `/plan` 단계에서는 파일을 수정하지 않는다.
