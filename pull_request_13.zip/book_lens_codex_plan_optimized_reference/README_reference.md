# Book Lens Codex patch reference

이 ZIP은 `IKNK-Labs/book-lens`의 `feature/kim-jeseok-frontend` 브랜치에 올려 Codex Cloud가 PR #10 이후 논의된 프론트엔드 shell 보강 작업을 수행할 때 참고하도록 만든 자료입니다.

## 포함 내용

- `codex_prompt_ko.md`: Codex에게 그대로 붙여넣을 작업 프롬프트
- `reference/html/`: Playwright 검증 전에 기준으로 사용한 정적 HTML 레이아웃
- `reference/screens/`: Playwright Chromium으로 렌더링한 스크린샷과 `report.json`
- `reference/notes/`: 라우트 매핑과 구현 결정 사항

## 사용 방법

1. 이 ZIP을 작업 브랜치에 임시로 올립니다.
2. Codex에게 `codex_prompt_ko.md`의 지시를 줍니다.
3. Codex는 ZIP을 임시 디렉터리에 풀어 참조한 뒤, 실제 구현은 `frontend/src` 코드에 반영합니다.
4. 패치 완료 전 이 ZIP과 압축 해제된 참조 폴더는 커밋에서 제거합니다.

## 주의

정적 HTML을 그대로 복사해 붙이는 작업이 아닙니다. 기존 Next.js/Tailwind 구조와 PR #10의 컴포넌트 톤을 유지하면서 라우트/컴포넌트를 보강해야 합니다.
